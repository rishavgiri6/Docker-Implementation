class Layer
  include ActiveModel::Model

  attr_accessor :index, :digest, :size
end